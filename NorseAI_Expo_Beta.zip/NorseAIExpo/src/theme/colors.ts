// src/theme/colors.ts
export const Colors = {
  bg:         '#06080F',
  surface:    '#0B0F1A',
  card:       '#111827',
  elevated:   '#141C2C',
  border:     '#1C2636',
  borderMid:  '#2A3850',
  text:       '#CDD4E4',
  textMid:    '#8898B0',
  textMuted:  '#506070',
  gold:       '#C9A84C',
  goldDim:    '#8A6E30',
  ice:        '#5AB4E8',
  iceDim:     '#2A6A99',
  danger:     '#E05252',
  dangerDim:  '#7A1F1F',
  warn:       '#D4882A',
  warnDim:    '#7A4B10',
  safe:       '#45C49A',
  safeDim:    '#1A6645',
  viking:     '#C9A84C',
  shield:     '#5AB4E8',
  scout:      '#8898B0',
};

export const Radius = {
  xs:  4,
  sm:  6,
  md:  10,
  lg:  14,
  xl:  20,
  full: 999,
};

export const Spacing = {
  xs:  4,
  sm:  8,
  md:  12,
  lg:  16,
  xl:  20,
  xxl: 28,
};
