// src/screens/HomeScreen.tsx
import React, { useEffect, useRef } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Animated, StatusBar,
} from 'react-native';
import Svg, { Circle, Polygon } from 'react-native-svg';
import { useNavigation } from '@react-navigation/native';
import * as Haptics from 'expo-haptics';
import { NorseLogo } from '../components/Logo';
import { Badge, Button } from '../components/UI';
import { useAppStore } from '../context/AppStore';
import { Colors, Spacing, Radius } from '../theme/colors';
import { Scanner } from '../services/ScannerService';
import { NorseNotifications } from '../services/NotificationService';
import { formatBytes, formatRelative } from '../utils/uuid';

const TIPS = [
  'Most data leaks come from forgotten screenshots. Enable Auto-Vault to secure them.',
  'The average user has 1,200+ photos — only 1 in 10 are intentionally shared.',
  'Screenshots often contain passwords, cards, and private messages you forgot about.',
  'Norse AI never uploads, stores, or transmits your media. Everything stays on-device.',
  'Enable Lock Screen Alert to confirm before sharing any flagged item.',
];

const FLAG_ICONS: Record<string, string> = {
  nsfw: '🔞', graphic: '⚠️', document: '📄',
  screenshot: '📷', substance: '💊', darkweb: '🌑',
};

export const HomeScreen: React.FC = () => {
  const nav      = useNavigation() as any;
  const store    = useAppStore();
  const pulse    = useRef(new Animated.Value(1)).current;
  const tip      = TIPS[new Date().getDate() % TIPS.length];

  const unsecured  = store.flags.filter(f => !f.secured).length;
  const secured    = store.flags.filter(f => f.secured).length;
  const score      = Math.max(45, Math.min(100, 100 - unsecured * 9));
  const scoreColor = score >= 75 ? Colors.safe : score >= 50 ? Colors.warn : Colors.danger;
  const circ       = 2 * Math.PI * 62;
  const tierColor  = store.tier === 'viking' ? Colors.gold : store.tier === 'shield' ? Colors.ice : Colors.scout;

  useEffect(() => {
    if (store.isScanning) {
      const anim = Animated.loop(
        Animated.sequence([
          Animated.timing(pulse, { toValue: 1.07, duration: 900, useNativeDriver: true }),
          Animated.timing(pulse, { toValue: 1.00, duration: 900, useNativeDriver: true }),
        ])
      );
      anim.start();
      return () => anim.stop();
    }
    pulse.setValue(1);
  }, [store.isScanning]);

  const startScan = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const ok = await Scanner.requestPermissions();
    if (!ok) return;

    store.setScanning(true);
    store.setScanProgress(0);
    store.setScanStage('Preparing…');

    try {
      const result = await Scanner.scanDevice(
        store.settings.sensitivity,
        {
          nsfw: store.settings.scanNSFW,
          violence: store.settings.scanViolence,
          substances: store.settings.scanSubstances,
          darkweb: store.settings.scanDarkweb,
          documents: store.settings.scanDocuments,
        },
        (p) => { store.setScanProgress(p.percentComplete); store.setScanStage(p.stage); }
      );

      for (const item of result.flaggedItems) store.addFlag(item);
      store.updateStats({
        totalPhotos: result.stats.totalPhotos,
        totalVideos: result.stats.totalVideos,
        totalScreenshots: result.stats.totalScreenshots,
        lastScanDate: new Date().toISOString(),
        storageAnalyzed: result.stats.bytesAnalyzed,
      });
      await NorseNotifications.scanComplete(result.flaggedItems.length, result.stats.totalScanned);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (e) {
      console.error('[Scan]', e);
    } finally {
      store.setScanning(false);
    }
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.bg} />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* ── Header ── */}
        <View style={styles.header}>
          <View style={styles.hLeft}>
            <NorseLogo size={38} />
            <View>
              <Text style={styles.brand}>NORSE</Text>
              <Text style={styles.brandSub}>GUARDIAN AI</Text>
            </View>
          </View>
          <View style={styles.hRight}>
            <Badge label={store.tier.toUpperCase()} color={tierColor} />
            <TouchableOpacity style={styles.bell} onPress={() => {}}>
              <Text style={{ fontSize: 16 }}>🔔</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* ── Shield Score Ring ── */}
        <View style={styles.scoreWrap}>
          <Animated.View style={{ transform: [{ scale: pulse }] }}>
            <Svg width={164} height={164} viewBox="0 0 164 164">
              <Circle cx="82" cy="82" r="62" fill="none" stroke={Colors.border} strokeWidth={9} />
              <Circle
                cx="82" cy="82" r="62" fill="none"
                stroke={scoreColor} strokeWidth={9}
                strokeDasharray={`${(circ * score / 100).toFixed(1)} ${circ}`}
                strokeLinecap="round"
                transform="rotate(-90 82 82)"
              />
              <Polygon
                points="82,30 110,46 110,78 82,94 54,78 54,46"
                fill="none" stroke={Colors.gold} strokeWidth="0.5" opacity="0.2"
              />
            </Svg>
          </Animated.View>
          <View style={styles.scoreOverlay}>
            <Text style={[styles.scoreNum, { color: scoreColor }]}>{score}</Text>
            <Text style={styles.scoreLbl}>SHIELD SCORE</Text>
          </View>
          <Text style={[styles.scoreStatus, { color: unsecured === 0 ? Colors.safe : Colors.warn }]}>
            {store.isScanning
              ? `◉  ${store.scanStage}`
              : unsecured === 0
                ? '✦  DEVICE FULLY PROTECTED'
                : `⚠  ${unsecured} ITEM${unsecured > 1 ? 'S' : ''} NEED REVIEW`}
          </Text>
        </View>

        {/* ── Stats ── */}
        <View style={styles.statsRow}>
          {[
            { l: 'Flagged', v: store.flags.length, c: Colors.danger },
            { l: 'Secured', v: secured, c: Colors.safe },
            { l: 'In Vault', v: store.vaultItems.length, c: Colors.gold },
          ].map(({ l, v, c }) => (
            <View key={l} style={styles.statCard}>
              <Text style={[styles.statNum, { color: c }]}>{v}</Text>
              <Text style={styles.statLbl}>{l}</Text>
            </View>
          ))}
        </View>

        {/* ── Scan Button ── */}
        <View style={styles.px}>
          <Button
            label={store.isScanning ? `SCANNING…  ${store.scanProgress}%` : '⟁  INITIATE DEEP SCAN'}
            onPress={store.isScanning ? () => Scanner.abort() : startScan}
            color={store.isScanning ? Colors.ice : Colors.gold}
            style={styles.scanBtn}
            textStyle={{ fontSize: 14, letterSpacing: 2 }}
          />
          {store.isScanning && (
            <View style={styles.progressTrack}>
              <View style={[styles.progressFill, { width: `${store.scanProgress}%` as any }]} />
            </View>
          )}
        </View>

        {/* ── Quick Tiles ── */}
        <View style={styles.grid}>
          {[
            { icon: '🔐', l: 'Norse Vault', s: `${store.vaultItems.length} items secured`, t: 'Vault' },
            { icon: '🛡', l: 'Scan Results', s: `${store.flags.length} flags`, t: 'Scan' },
            { icon: '⚡', l: 'AI Tips', s: '3 new insights', t: 'Settings' },
            { icon: '📊', l: 'Data Report', s: formatBytes(store.stats.storageAnalyzed) + ' analyzed', t: 'Settings' },
          ].map(({ icon, l, s, t }) => (
            <TouchableOpacity key={l} style={styles.tile} onPress={() => nav.navigate(t)} activeOpacity={0.75}>
              <Text style={{ fontSize: 26, marginBottom: 6 }}>{icon}</Text>
              <Text style={styles.tileLbl}>{l}</Text>
              <Text style={styles.tileSub}>{s}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* ── Recent Flags ── */}
        {store.flags.length > 0 && (
          <View style={styles.px}>
            <View style={styles.secRow}>
              <Text style={styles.secTitle}>RECENT FLAGS</Text>
              <TouchableOpacity onPress={() => nav.navigate('Scan')}>
                <Text style={{ fontSize: 12, color: Colors.ice }}>View all →</Text>
              </TouchableOpacity>
            </View>
            {store.flags.slice(0, 3).map(f => (
              <TouchableOpacity
                key={f.id} activeOpacity={0.75}
                style={styles.flagRow}
                onPress={() => nav.navigate('LockAlert', { flag: f })}
              >
                <View style={[styles.flagIcon, { backgroundColor: Colors.danger + '20', borderColor: Colors.danger + '40' }]}>
                  <Text style={{ fontSize: 20 }}>{FLAG_ICONS[f.type] ?? '📄'}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.flagCat}>{f.category}</Text>
                  <Text style={styles.flagDate}>{formatRelative(f.detectedAt)} · Tap to review</Text>
                </View>
                <View style={[styles.dot, { backgroundColor: f.secured ? Colors.safe : Colors.danger }]} />
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* ── Tip Card ── */}
        <View style={styles.tipCard}>
          <Text style={styles.tipLbl}>⚡  NORSE TIP</Text>
          <Text style={styles.tipTxt}>{tip}</Text>
        </View>

      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.bg },
  scroll: { paddingBottom: 28 },
  px: { paddingHorizontal: Spacing.lg },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingTop: 16, paddingBottom: 4,
  },
  hLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  hRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  brand: { fontSize: 17, color: Colors.gold, letterSpacing: 4, fontWeight: '700', lineHeight: 20 },
  brandSub: { fontSize: 9, color: Colors.textMuted, letterSpacing: 4 },
  bell: {
    width: 32, height: 32, borderRadius: 16, backgroundColor: Colors.card,
    borderWidth: 0.5, borderColor: Colors.border, alignItems: 'center', justifyContent: 'center',
  },
  scoreWrap: { alignItems: 'center', paddingVertical: 10 },
  scoreOverlay: {
    position: 'absolute', top: '50%', left: '50%',
    transform: [{ translateX: -42 }, { translateY: -30 }], alignItems: 'center',
  },
  scoreNum: { fontSize: 38, fontWeight: '700', lineHeight: 44 },
  scoreLbl: { fontSize: 9, color: Colors.textMuted, letterSpacing: 1.5, marginTop: 2 },
  scoreStatus: { fontSize: 11, letterSpacing: 1, marginTop: 4 },
  statsRow: { flexDirection: 'row', gap: 8, paddingHorizontal: Spacing.lg, paddingBottom: 12 },
  statCard: {
    flex: 1, backgroundColor: Colors.card, borderRadius: Radius.md,
    borderWidth: 0.5, borderColor: Colors.border, padding: 12, alignItems: 'center',
  },
  statNum: { fontSize: 22, fontWeight: '700', lineHeight: 26 },
  statLbl: { fontSize: 10, color: Colors.textMuted, marginTop: 3 },
  scanBtn: { marginBottom: 0 },
  progressTrack: { height: 3, backgroundColor: Colors.border, borderRadius: 2, marginTop: 8, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: Colors.ice, borderRadius: 2 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, padding: Spacing.lg, paddingTop: 14 },
  tile: {
    width: '47.5%', backgroundColor: Colors.card,
    borderRadius: Radius.md, borderWidth: 0.5, borderColor: Colors.border, padding: 14,
  },
  tileLbl: { fontSize: 13, fontWeight: '500', color: Colors.text },
  tileSub: { fontSize: 11, color: Colors.textMuted, marginTop: 2 },
  secRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10, marginTop: 4 },
  secTitle: { fontSize: 10, color: Colors.textMuted, letterSpacing: 2, fontWeight: '600' },
  flagRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: Colors.card, borderRadius: Radius.md, padding: 10,
    borderWidth: 0.5, borderColor: Colors.border, marginBottom: 8,
  },
  flagIcon: { width: 46, height: 46, borderRadius: 8, borderWidth: 1, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  flagCat: { fontSize: 13, fontWeight: '500', color: Colors.text },
  flagDate: { fontSize: 11, color: Colors.textMuted, marginTop: 1 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  tipCard: {
    margin: Spacing.lg, marginTop: 8, padding: 14, borderRadius: Radius.md,
    backgroundColor: Colors.gold + '0E', borderWidth: 0.5, borderColor: Colors.gold + '30',
  },
  tipLbl: { fontSize: 10, color: Colors.gold, letterSpacing: 2, fontWeight: '700', marginBottom: 4 },
  tipTxt: { fontSize: 12, color: Colors.textMid, lineHeight: 18 },
});
