// src/screens/PlansScreen.tsx
import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { useAppStore, Tier } from '../context/AppStore';
import { NorseBrand } from '../components/Logo';
import { Colors, Spacing, Radius } from '../theme/colors';

const PLANS = [
  {
    id: 'scout' as Tier, name: 'SCOUT', sub: 'Free forever', price: 'FREE', color: Colors.textMid,
    features: [
      { l: 'Basic device scan', ok: true },
      { l: '3-window alert limit', ok: true },
      { l: '10 vault items', ok: true },
      { l: 'Manual operations only', ok: true },
      { l: 'Auto scan', ok: false },
      { l: 'Sensitivity control', ok: false },
      { l: 'Data assessment', ok: false },
    ],
  },
  {
    id: 'shield' as Tier, name: 'SHIELD', sub: 'Most popular', price: '$4.99/mo', priceAnnual: '$39.99/yr', color: Colors.ice, pop: true,
    features: [
      { l: 'All Scout features', ok: true },
      { l: 'Auto-scan on new media', ok: true },
      { l: 'Sensitivity control 1–7', ok: true },
      { l: '5-window alert limit', ok: true },
      { l: 'Unlimited vault', ok: true },
      { l: 'Data usage assessment', ok: true },
      { l: 'AI pro tips & insights', ok: true },
    ],
  },
  {
    id: 'viking' as Tier, name: 'VIKING', sub: 'Elite guard', price: '$12.99/mo', priceAnnual: '$99.99/yr', color: Colors.gold,
    features: [
      { l: 'All Shield features', ok: true },
      { l: '7-window alert limit', ok: true },
      { l: 'Data migration ★', ok: true, soon: true },
      { l: 'Data tracking ★', ok: true, soon: true },
      { l: 'Priority AI scanning', ok: true },
      { l: 'Full report exports', ok: true },
      { l: 'Norse Elite badge', ok: true },
    ],
  },
];

const PAY = [
  { l: 'Bitcoin',    icon: '₿', c: '#F7931A' },
  { l: 'Ethereum',   icon: 'Ξ', c: '#627EEA' },
  { l: 'Apple Pay',  icon: '',  c: Colors.text },
  { l: 'Google Pay', icon: 'G', c: Colors.ice  },
  { l: 'Solana',     icon: '◎', c: '#9945FF'  },
  { l: 'USDC',       icon: '$', c: Colors.safe },
];

export const PlansScreen: React.FC = () => {
  const store = useAppStore();

  return (
    <View style={s.root}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 36 }}>

        <View style={s.top}>
          <NorseBrand width={220} style={{ marginBottom: 12 }} />
          <Text style={s.hTitle}>CHOOSE YOUR SHIELD</Text>
          <Text style={s.hSub}>Crypto & Mobile Pay only · No cards required</Text>
        </View>

        {PLANS.map(p => (
          <View key={p.id} style={[s.card, { borderColor: store.tier === p.id ? p.color : Colors.border, borderWidth: store.tier === p.id ? 1.5 : 0.5 }]}>
            {(p as any).pop && (
              <View style={[s.popBanner, { backgroundColor: p.color + '22' }]}>
                <Text style={[s.popTxt, { color: p.color }]}>★  MOST POPULAR</Text>
              </View>
            )}
            <View style={s.cardHead}>
              <View>
                <Text style={[s.planName, { color: p.color }]}>{p.name}</Text>
                <Text style={s.planSub}>{p.sub}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={[s.planPrice, { color: p.color }]}>{p.price}</Text>
                {(p as any).priceAnnual && <Text style={s.planAnnual}>{(p as any).priceAnnual}</Text>}
              </View>
            </View>

            {p.features.map(f => (
              <View key={f.l} style={s.feat}>
                <Text style={{ color: f.ok ? p.color : Colors.textMuted, fontSize: 12 }}>{f.ok ? '✓' : '✗'}</Text>
                <Text style={[s.featTxt, { color: f.ok ? Colors.textMid : Colors.textMuted }]}>
                  {f.l.replace(' ★', '')}
                  {(f as any).soon && <Text style={{ color: Colors.gold, fontSize: 10 }}> (coming soon)</Text>}
                </Text>
              </View>
            ))}

            <TouchableOpacity
              style={[s.upgradeBtn, { borderColor: store.tier === p.id ? p.color + '40' : p.color, backgroundColor: store.tier === p.id ? 'transparent' : p.color + '14' }]}
              onPress={() => store.setTier(p.id)}
              activeOpacity={0.75}
            >
              <Text style={[s.upgradeTxt, { color: store.tier === p.id ? p.color + '80' : p.color }]}>
                {store.tier === p.id ? '✓  CURRENT PLAN' : `UPGRADE TO ${p.name}`}
              </Text>
            </TouchableOpacity>
          </View>
        ))}

        <Text style={s.payTitle}>PAYMENT METHODS</Text>
        <View style={s.payGrid}>
          {PAY.map(m => (
            <View key={m.l} style={s.payCard}>
              <Text style={[s.payIcon, { color: m.c }]}>{m.icon}</Text>
              <Text style={s.payLbl}>{m.l}</Text>
            </View>
          ))}
        </View>
        <Text style={s.payNote}>BTC · ETH · SOL · USDC · Apple Pay · Google Pay{'\n'}No card data ever stored</Text>
      </ScrollView>
    </View>
  );
};

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.bg },
  top: { alignItems: 'center', paddingTop: 20, paddingBottom: 8, paddingHorizontal: Spacing.lg },
  hTitle: { fontSize: 17, color: Colors.text, letterSpacing: 3 },
  hSub: { fontSize: 11, color: Colors.textMuted, marginTop: 4 },
  card: { marginHorizontal: Spacing.lg, marginBottom: 12, borderRadius: Radius.lg, backgroundColor: Colors.card, overflow: 'hidden' },
  popBanner: { paddingVertical: 6, alignItems: 'center' },
  popTxt: { fontSize: 10, letterSpacing: 2, fontWeight: '700' },
  cardHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', padding: Spacing.lg, paddingBottom: 10 },
  planName: { fontSize: 20, letterSpacing: 2, fontWeight: '700' },
  planSub: { fontSize: 11, color: Colors.textMuted, marginTop: 2 },
  planPrice: { fontSize: 18, fontWeight: '700' },
  planAnnual: { fontSize: 10, color: Colors.textMuted, marginTop: 2 },
  feat: { flexDirection: 'row', gap: 8, paddingHorizontal: Spacing.lg, paddingVertical: 3 },
  featTxt: { fontSize: 12, flex: 1, lineHeight: 18 },
  upgradeBtn: { margin: Spacing.lg, marginTop: 14, paddingVertical: 13, borderRadius: Radius.md, borderWidth: 1, alignItems: 'center' },
  upgradeTxt: { fontSize: 13, fontWeight: '700', letterSpacing: 1.5 },
  payTitle: { fontSize: 10, color: Colors.textMuted, letterSpacing: 2, textAlign: 'center', paddingTop: 8, paddingBottom: 12 },
  payGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingHorizontal: Spacing.lg, justifyContent: 'center' },
  payCard: { width: '30%', backgroundColor: Colors.elevated, borderRadius: Radius.md, borderWidth: 0.5, borderColor: Colors.border, padding: 10, alignItems: 'center' },
  payIcon: { fontSize: 20, fontWeight: '700', lineHeight: 26 },
  payLbl: { fontSize: 10, color: Colors.textMuted, marginTop: 4 },
  payNote: { textAlign: 'center', fontSize: 10, color: Colors.textMuted, padding: Spacing.lg, paddingTop: 10, lineHeight: 16 },
});
