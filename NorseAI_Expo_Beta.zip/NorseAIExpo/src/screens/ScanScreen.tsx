// src/screens/ScanScreen.tsx
import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import * as Haptics from 'expo-haptics';
import { useAppStore, FlaggedItem } from '../context/AppStore';
import { Button, Badge, SH } from '../components/UI';
import { Colors, Spacing, Radius } from '../theme/colors';
import { Vault } from '../services/VaultService';
import { Scanner } from '../services/ScannerService';
import { NorseNotifications } from '../services/NotificationService';
import { formatRelative, formatDate } from '../utils/uuid';

const FLAG_ICONS: Record<string, string> = { nsfw: '🔞', graphic: '⚠️', document: '📄', screenshot: '📷', substance: '💊', darkweb: '🌑' };
const SEV_COLOR: Record<string, string> = { critical: Colors.danger, high: Colors.warn, medium: Colors.gold, low: Colors.ice };

export const ScanScreen: React.FC = () => {
  const nav   = useNavigation() as any;
  const store = useAppStore();
  const [selMode,  setSelMode]  = useState(false);
  const [selected, setSelected] = useState<string[]>([]);
  const [filter,   setFilter]   = useState<'all' | 'unsecured' | 'secured'>('all');

  const cats = [
    { l: 'Photos',      count: store.stats.totalPhotos,      flagged: store.flags.filter(f => !['document','screenshot'].includes(f.type)).length, icon: '📸' },
    { l: 'Videos',      count: store.stats.totalVideos,      flagged: 0,                                                                            icon: '🎬' },
    { l: 'Screenshots', count: store.stats.totalScreenshots, flagged: store.flags.filter(f => f.type === 'screenshot').length,                      icon: '📷' },
    { l: 'Documents',   count: 0,                            flagged: store.flags.filter(f => f.type === 'document').length,                        icon: '📁' },
  ];

  const filtered = store.flags.filter(f =>
    filter === 'all' ? true : filter === 'unsecured' ? !f.secured : f.secured
  );

  const toggle = (id: string) =>
    setSelected(s => s.includes(id) ? s.filter(i => i !== id) : [...s, id]);

  const handleVault = async (f: FlaggedItem) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const entry = await Vault.addToVault(f.uri);
    if (entry) {
      store.moveToVault(f.id);
      Alert.alert('Vault ✓', 'Item moved to your encrypted Norse Vault.');
    }
  };

  const handleDelete = (id: string) =>
    Alert.alert(
      'Delete from This Device',
      'Removes the item from this device\'s local storage only.\nNorse AI holds no external copies.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: () => { store.deleteFlag(id); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning); } },
      ]
    );

  const deleteBulk = () =>
    Alert.alert(
      `Delete ${selected.length} Items`,
      'Removes from this device only. Norse AI stores nothing externally.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: `Delete ${selected.length}`, style: 'destructive',
          onPress: () => { store.deleteBulk(selected); setSelected([]); setSelMode(false); }
        },
      ]
    );

  const rescan = async () => {
    const ok = await Scanner.requestPermissions();
    if (!ok) return;
    store.setScanning(true);
    store.setScanProgress(0);
    const result = await Scanner.scanDevice(
      store.settings.sensitivity,
      { nsfw: store.settings.scanNSFW, violence: store.settings.scanViolence, substances: store.settings.scanSubstances, darkweb: store.settings.scanDarkweb, documents: store.settings.scanDocuments },
      p => { store.setScanProgress(p.percentComplete); store.setScanStage(p.stage); }
    );
    for (const item of result.flaggedItems) store.addFlag(item);
    await NorseNotifications.scanComplete(result.flaggedItems.length, result.stats.totalScanned);
    store.setScanning(false);
  };

  return (
    <View style={s.root}>
      {/* Header */}
      <View style={s.header}>
        <View>
          <Text style={s.title}>Scan Results</Text>
          {store.stats.lastScanDate && <Text style={s.sub}>Last scan {formatDate(store.stats.lastScanDate)}</Text>}
        </View>
        <TouchableOpacity style={s.rescanBtn} onPress={rescan}>
          <Text style={{ color: Colors.ice, fontSize: 12, letterSpacing: 1 }}>
            {store.isScanning ? `${store.scanProgress}%` : 'RESCAN'}
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
        {/* Category grid */}
        <View style={s.catGrid}>
          {cats.map(c => (
            <View key={c.l} style={[s.catCard, c.flagged > 0 && { borderColor: Colors.warn + '55' }]}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Text style={{ fontSize: 22 }}>{c.icon}</Text>
                {c.flagged > 0 && <Badge label={`${c.flagged} ⚠`} color={Colors.danger} />}
              </View>
              <Text style={s.catNum}>{c.count.toLocaleString()}</Text>
              <Text style={s.catLbl}>{c.l}</Text>
            </View>
          ))}
        </View>

        {/* Filter tabs */}
        <View style={s.filterRow}>
          {(['all', 'unsecured', 'secured'] as const).map(f => (
            <TouchableOpacity
              key={f} style={[s.tab, filter === f && { borderColor: Colors.ice, backgroundColor: Colors.ice + '12' }]}
              onPress={() => setFilter(f)}
            >
              <Text style={{ color: filter === f ? Colors.ice : Colors.textMuted, fontSize: 12 }}>
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity style={[s.tab, { marginLeft: 'auto' as any }]} onPress={() => { setSelMode(!selMode); setSelected([]); }}>
            <Text style={{ color: selMode ? Colors.danger : Colors.textMid, fontSize: 12 }}>{selMode ? 'Cancel' : 'Select'}</Text>
          </TouchableOpacity>
        </View>

        <SH label={`FLAGGED (${filtered.length})`} />

        <View style={{ paddingHorizontal: Spacing.lg }}>
          {filtered.length === 0 && (
            <View style={s.empty}>
              <Text style={{ fontSize: 32 }}>✦</Text>
              <Text style={{ color: Colors.safe, fontSize: 13, marginTop: 8, letterSpacing: 1 }}>NO FLAGS IN THIS VIEW</Text>
            </View>
          )}
          {filtered.map(f => (
            <TouchableOpacity
              key={f.id}
              style={[s.flagRow, selected.includes(f.id) && { borderColor: Colors.danger + '60', backgroundColor: Colors.danger + '08' }]}
              onPress={() => selMode ? toggle(f.id) : nav.navigate('LockAlert', { flag: f })}
              activeOpacity={0.75}
            >
              {selMode && (
                <View style={[s.checkbox, selected.includes(f.id) && { backgroundColor: Colors.danger, borderColor: Colors.danger }]}>
                  {selected.includes(f.id) && <Text style={{ color: '#fff', fontSize: 10 }}>✓</Text>}
                </View>
              )}
              <View style={[s.flagIcon, { backgroundColor: SEV_COLOR[f.severity] + '20', borderColor: SEV_COLOR[f.severity] + '40' }]}>
                <Text style={{ fontSize: 20 }}>{FLAG_ICONS[f.type] ?? '📄'}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                  <Text style={s.flagCat}>{f.category}</Text>
                  {f.secured  && <Badge label="SECURED" color={Colors.safe} />}
                  {f.inVault  && <Badge label="VAULT"   color={Colors.gold} />}
                </View>
                <Text style={s.flagDate}>{formatRelative(f.detectedAt)} · {Math.round(f.confidence * 100)}% match</Text>
              </View>
              {!selMode && (
                <View style={{ flexDirection: 'row', gap: 6 }}>
                  <TouchableOpacity style={[s.actBtn, { backgroundColor: Colors.gold + '20', borderColor: Colors.gold + '50' }]} onPress={() => handleVault(f)}>
                    <Text style={{ fontSize: 14 }}>🔐</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={[s.actBtn, { backgroundColor: Colors.danger + '20', borderColor: Colors.danger + '50' }]} onPress={() => handleDelete(f.id)}>
                    <Text style={{ fontSize: 14 }}>🗑</Text>
                  </TouchableOpacity>
                </View>
              )}
            </TouchableOpacity>
          ))}

          {selected.length > 0 && (
            <Button
              label={`🗑  DELETE ${selected.length} FROM THIS DEVICE ONLY`}
              onPress={deleteBulk} color={Colors.danger}
              style={{ marginTop: 6 }}
            />
          )}
        </View>

        <View style={s.disclaimer}>
          <Text style={s.disclaimerTxt}>
            ⚠  Norse AI deletes from this device's local storage only. No data is held or transmitted externally.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
};

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.bg },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: Spacing.lg, paddingBottom: 8 },
  title: { fontSize: 22, color: Colors.text, letterSpacing: 1 },
  sub: { fontSize: 11, color: Colors.textMuted, marginTop: 2 },
  rescanBtn: { borderWidth: 1, borderColor: Colors.ice + '50', borderRadius: Radius.sm, paddingVertical: 6, paddingHorizontal: 12 },
  catGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingHorizontal: Spacing.lg, paddingBottom: 10 },
  catCard: { width: '47.5%', backgroundColor: Colors.card, borderRadius: Radius.md, borderWidth: 0.5, borderColor: Colors.border, padding: 12 },
  catNum: { fontSize: 22, fontWeight: '700', color: Colors.ice, marginTop: 6, lineHeight: 26 },
  catLbl: { fontSize: 11, color: Colors.textMuted, marginTop: 2 },
  filterRow: { flexDirection: 'row', gap: 8, paddingHorizontal: Spacing.lg, paddingBottom: 4, alignItems: 'center' },
  tab: { paddingVertical: 5, paddingHorizontal: 10, borderRadius: Radius.sm, borderWidth: 0.5, borderColor: Colors.border },
  flagRow: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: Colors.card, borderRadius: Radius.md, padding: 10,
    borderWidth: 0.5, borderColor: Colors.border, marginBottom: 8,
  },
  checkbox: { width: 22, height: 22, borderRadius: 11, borderWidth: 2, borderColor: Colors.textMuted, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  flagIcon: { width: 46, height: 46, borderRadius: 8, borderWidth: 1, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  flagCat: { fontSize: 13, fontWeight: '500', color: Colors.text },
  flagDate: { fontSize: 11, color: Colors.textMuted, marginTop: 1 },
  actBtn: { width: 32, height: 32, borderRadius: Radius.sm, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  empty: { alignItems: 'center', paddingVertical: 40 },
  disclaimer: { margin: Spacing.lg, padding: 12, backgroundColor: Colors.surface, borderRadius: Radius.md, borderWidth: 0.5, borderColor: Colors.border },
  disclaimerTxt: { fontSize: 11, color: Colors.textMuted, lineHeight: 16 },
});
