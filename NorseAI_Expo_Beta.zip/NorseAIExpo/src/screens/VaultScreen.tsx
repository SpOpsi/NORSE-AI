// src/screens/VaultScreen.tsx
import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, Image } from 'react-native';
import { Vault, VaultEntry } from '../services/VaultService';
import { useAppStore } from '../context/AppStore';
import { Button } from '../components/UI';
import { Colors, Spacing, Radius } from '../theme/colors';
import { formatBytes } from '../utils/uuid';

export const VaultScreen: React.FC = () => {
  const store = useAppStore();
  const [entries, setEntries] = useState<VaultEntry[]>([]);
  const [size,    setSize]    = useState(0);
  const [authed,  setAuthed]  = useState(!store.settings.biometricLock);

  const auth = async () => {
    const ok = await Vault.authenticate();
    setAuthed(ok);
    if (!ok) Alert.alert('Authentication Failed', 'Could not verify your identity. Try again.');
  };

  const load = async () => {
    const e = await Vault.getEntries();
    const s = await Vault.getVaultSize();
    setEntries(e); setSize(s);
  };

  useEffect(() => {
    if (authed) load();
    else auth();
  }, [authed]);

  const remove = (id: string) =>
    Alert.alert('Remove from Vault', 'The item is restored to your gallery.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: async () => { await Vault.removeEntry(id); load(); } },
    ]);

  if (!authed) return (
    <View style={[s.root, { alignItems: 'center', justifyContent: 'center', gap: 16, padding: 40 }]}>
      <Text style={{ fontSize: 48 }}>🔒</Text>
      <Text style={{ fontSize: 18, color: Colors.gold, letterSpacing: 2 }}>NORSE VAULT</Text>
      <Text style={{ fontSize: 12, color: Colors.textMuted, textAlign: 'center', lineHeight: 18 }}>
        Authenticate with Face ID or fingerprint to access your secure vault.
      </Text>
      <Button label="AUTHENTICATE" onPress={auth} color={Colors.gold} style={{ width: '100%' }} />
    </View>
  );

  return (
    <View style={s.root}>
      <View style={s.header}>
        <View>
          <Text style={s.title}>Norse Vault</Text>
          <Text style={s.sub}>{entries.length} items · {formatBytes(size)} · On-device only</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 28 }}>
        {/* Stats */}
        <View style={s.statsRow}>
          {[
            { l: 'Items',    v: `${entries.length}`,           c: Colors.gold },
            { l: 'Size',     v: formatBytes(size),             c: Colors.ice  },
            { l: 'Auto-add', v: store.settings.autoVault ? 'ON' : 'OFF', c: store.settings.autoVault ? Colors.safe : Colors.textMuted },
          ].map(({ l, v, c }) => (
            <View key={l} style={s.statCard}>
              <Text style={[s.statNum, { color: c }]}>{v}</Text>
              <Text style={s.statLbl}>{l}</Text>
            </View>
          ))}
        </View>

        {entries.length === 0 ? (
          <View style={s.empty}>
            <Text style={{ fontSize: 48, marginBottom: 12 }}>🔐</Text>
            <Text style={{ color: Colors.textMid, fontSize: 13, textAlign: 'center', lineHeight: 20 }}>
              Your vault is empty.{'\n'}Secure flagged items from the Scan tab.
            </Text>
          </View>
        ) : (
          <View style={s.grid}>
            {entries.map(e => (
              <TouchableOpacity key={e.id} style={s.thumb} onLongPress={() => remove(e.id)} activeOpacity={0.8}>
                <Image source={{ uri: e.vaultPath }} style={s.thumbImg} />
                <View style={s.thumbOverlay}>
                  <Text style={{ fontSize: 20 }}>🔐</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        )}

        <View style={{ paddingHorizontal: Spacing.lg, paddingTop: 16 }}>
          <View style={s.infoCard}>
            <Text style={s.infoTitle}>🛡  VAULT SECURITY</Text>
            <Text style={s.infoText}>
              All vault content is encrypted and stored only on this device using hardware-backed security.
              Norse AI never uploads or accesses your vault contents.{'\n\n'}
              Long-press any item to remove it from the vault.
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.bg },
  header: { padding: Spacing.lg, paddingBottom: 8 },
  title: { fontSize: 22, color: Colors.text, letterSpacing: 1 },
  sub: { fontSize: 11, color: Colors.textMuted, marginTop: 2 },
  statsRow: { flexDirection: 'row', gap: 8, paddingHorizontal: Spacing.lg, paddingBottom: 12 },
  statCard: { flex: 1, backgroundColor: Colors.card, borderRadius: Radius.md, borderWidth: 0.5, borderColor: Colors.border, padding: 12, alignItems: 'center' },
  statNum: { fontSize: 16, fontWeight: '700', lineHeight: 20 },
  statLbl: { fontSize: 10, color: Colors.textMuted, marginTop: 3 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 3, paddingHorizontal: Spacing.lg },
  thumb: { width: '32%', aspectRatio: 1, borderRadius: Radius.sm, overflow: 'hidden', backgroundColor: Colors.elevated },
  thumbImg: { width: '100%', height: '100%' },
  thumbOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(6,8,15,0.72)', alignItems: 'center', justifyContent: 'center' },
  empty: { alignItems: 'center', paddingVertical: 60 },
  infoCard: { backgroundColor: Colors.card, borderRadius: Radius.md, borderWidth: 0.5, borderColor: Colors.border, padding: 16 },
  infoTitle: { fontSize: 11, color: Colors.gold, letterSpacing: 2, fontWeight: '700', marginBottom: 8 },
  infoText: { fontSize: 12, color: Colors.textMid, lineHeight: 18 },
});
