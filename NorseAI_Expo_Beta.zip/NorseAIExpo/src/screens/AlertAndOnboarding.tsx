// src/screens/AlertAndOnboarding.tsx
import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated, Vibration } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import * as Haptics from 'expo-haptics';
import { NorseLogo, NorseBrand } from '../components/Logo';
import { useAppStore, FlaggedItem } from '../context/AppStore';
import { Colors, Spacing, Radius } from '../theme/colors';

const SEV_COLOR: Record<string, string>  = { critical: Colors.danger, high: Colors.warn, medium: Colors.gold, low: Colors.ice };
const TYPE_ICON: Record<string, string>  = { nsfw: '🔞', graphic: '⚠️', document: '📄', substance: '💊', darkweb: '🌑', screenshot: '📷' };

// ─── Lock Screen Alert ────────────────────────────────────────────────────────
export const LockAlertScreen: React.FC = () => {
  const nav   = useNavigation() as any;
  const route = useRoute() as any;
  const store = useAppStore();
  const flag  = route.params?.flag as FlaggedItem;
  const pulse = useRef(new Animated.Value(1)).current;
  const sevColor = SEV_COLOR[flag?.severity ?? 'high'];

  useEffect(() => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1.09, duration: 900, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 1.00, duration: 900, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, []);

  if (!flag) { nav.goBack(); return null; }

  const onSecure = async () => {
    store.secureFlag(flag.id);
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    nav.goBack();
  };
  const onVault  = async () => {
    store.moveToVault(flag.id);
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    nav.goBack();
  };
  const onProceed = () => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy); nav.goBack(); };

  return (
    <View style={al.root}>
      <Animated.View style={{ transform: [{ scale: pulse }] }}>
        <NorseLogo size={80} />
      </Animated.View>

      <Text style={al.alertLabel}>⚠  NORSE GUARD ALERT</Text>

      <View style={[al.iconBox, { backgroundColor: sevColor + '20', borderColor: sevColor + '70' }]}>
        <Text style={{ fontSize: 44 }}>{TYPE_ICON[flag.type] ?? '⚠️'}</Text>
      </View>

      <Text style={al.title}>{flag.category} Detected</Text>
      <Text style={al.desc}>
        Norse AI flagged this content as sensitive ({Math.round(flag.confidence * 100)}% confidence).
        Sharing may expose private data outside your device's protection.
      </Text>

      <View style={al.warnBox}>
        <Text style={al.warnTxt}>
          Proceeding releases this item from device protection.{'\n'}
          Norse AI only warns — never blocks. The choice is yours.
        </Text>
      </View>

      <View style={al.actions}>
        <TouchableOpacity style={[al.btn, { borderColor: Colors.gold, backgroundColor: Colors.gold + '18' }]} onPress={onVault} activeOpacity={0.75}>
          <Text style={[al.btnTxt, { color: Colors.gold }]}>🔐  MOVE TO VAULT</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[al.btn, { borderColor: Colors.safe, backgroundColor: Colors.safe + '18' }]} onPress={onSecure} activeOpacity={0.75}>
          <Text style={[al.btnTxt, { color: Colors.safe }]}>🛡  MARK SECURED</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[al.btn, { borderColor: Colors.danger, backgroundColor: Colors.danger + '14' }]} onPress={onProceed} activeOpacity={0.75}>
          <Text style={[al.btnTxt, { color: Colors.danger }]}>PROCEED ANYWAY</Text>
        </TouchableOpacity>
      </View>

      <Text style={{ fontSize: 11, color: Colors.textMuted }}>Norse AI — Your Digital Sentry</Text>
    </View>
  );
};

// ─── Onboarding ───────────────────────────────────────────────────────────────
const STEPS = [
  { icon: '🛡', title: 'Meet Norse AI',    body: 'Your on-device digital guardian. We scan, flag, and protect your sensitive media — without ever sending a single byte off your device.' },
  { icon: '🔞', title: 'Smart Detection',  body: 'Norse AI detects adult content, graphic violence, personal documents, and sensitive data across all your photos and files — on-device only.' },
  { icon: '🔐', title: 'Norse Vault',       body: 'Flagged items move to your encrypted vault — accessible only by your face or fingerprint, stored only on this device. Never in the cloud.' },
  { icon: '⚠️', title: 'Guard Alerts',      body: 'Enable Lock Screen Alert and Norse AI intercepts before you share a sensitive item — giving you a moment to protect what\'s private.' },
  { icon: '◉',  title: 'Zero Data Policy', body: 'Nothing leaves your device. No accounts, no servers, no cloud sync. Norse AI is a tool that lives on your phone and serves only you.' },
];

export const OnboardingScreen: React.FC = () => {
  const store = useAppStore();
  const [step, setStep] = React.useState(0);
  const fade = useRef(new Animated.Value(1)).current;

  const advance = () => {
    if (step === STEPS.length - 1) { store.setOnboarded(true); return; }
    Animated.sequence([
      Animated.timing(fade, { toValue: 0, duration: 180, useNativeDriver: true }),
    ]).start(() => {
      setStep(s => s + 1);
      Animated.timing(fade, { toValue: 1, duration: 300, useNativeDriver: true }).start();
    });
    Haptics.selectionAsync();
  };

  const st = STEPS[step];

  return (
    <View style={ob.root}>
      <Animated.View style={[ob.inner, { opacity: fade }]}>
        {step === 0
          ? <NorseBrand width={240} style={{ marginBottom: 4 }} />
          : <NorseLogo size={64} />
        }
        <Text style={ob.icon}>{st.icon}</Text>
        <Text style={ob.title}>{st.title}</Text>
        <Text style={ob.body}>{st.body}</Text>

        <View style={ob.dots}>
          {STEPS.map((_, i) => (
            <View key={i} style={[ob.dot, {
              backgroundColor: i === step ? Colors.gold : Colors.border,
              width: i === step ? 22 : 6,
            }]} />
          ))}
        </View>

        <TouchableOpacity style={ob.btn} onPress={advance} activeOpacity={0.75}>
          <Text style={ob.btnTxt}>
            {step === STEPS.length - 1 ? 'ENTER THE REALM' : 'CONTINUE'}
          </Text>
        </TouchableOpacity>

        {step > 0 && (
          <TouchableOpacity onPress={() => store.setOnboarded(true)} style={{ marginTop: 16 }}>
            <Text style={{ color: Colors.textMuted, fontSize: 12 }}>Skip intro</Text>
          </TouchableOpacity>
        )}
      </Animated.View>
    </View>
  );
};

// ─── Styles ───────────────────────────────────────────────────────────────────
const al = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.bg, alignItems: 'center', justifyContent: 'center', padding: 32, gap: 14 },
  alertLabel: { fontSize: 11, color: Colors.danger, letterSpacing: 3, fontWeight: '700' },
  iconBox: { width: 94, height: 94, borderRadius: 20, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 20, fontWeight: '600', color: Colors.text, textAlign: 'center' },
  desc: { fontSize: 13, color: Colors.textMid, textAlign: 'center', lineHeight: 20, maxWidth: 300 },
  warnBox: { padding: 12, backgroundColor: Colors.danger + '10', borderRadius: Radius.md, borderWidth: 0.5, borderColor: Colors.danger + '40', width: '100%' },
  warnTxt: { fontSize: 12, color: Colors.danger, lineHeight: 18, textAlign: 'center' },
  actions: { width: '100%', gap: 10 },
  btn: { paddingVertical: 15, borderRadius: Radius.md, borderWidth: 1, alignItems: 'center' },
  btnTxt: { fontSize: 13, fontWeight: '700', letterSpacing: 1 },
});

const ob = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.bg, alignItems: 'center', justifyContent: 'center', padding: 40 },
  inner: { alignItems: 'center', width: '100%' },
  icon: { fontSize: 52, marginTop: 24, marginBottom: 6 },
  title: { fontSize: 24, color: Colors.gold, letterSpacing: 2, textAlign: 'center', marginBottom: 14, fontWeight: '700' },
  body: { fontSize: 15, color: Colors.textMid, lineHeight: 24, textAlign: 'center', marginBottom: 32, maxWidth: 320 },
  dots: { flexDirection: 'row', gap: 6, marginBottom: 28 },
  dot: { height: 6, borderRadius: 3 },
  btn: { width: '100%', paddingVertical: 16, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.gold, backgroundColor: Colors.gold + '14', alignItems: 'center' },
  btnTxt: { fontSize: 14, color: Colors.gold, letterSpacing: 2, fontWeight: '700' },
});
