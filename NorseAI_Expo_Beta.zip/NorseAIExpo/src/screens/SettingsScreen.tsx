// src/screens/SettingsScreen.tsx
import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useAppStore } from '../context/AppStore';
import { Toggle, Row, SH, Button } from '../components/UI';
import { Colors, Spacing, Radius } from '../theme/colors';

export const SettingsScreen: React.FC = () => {
  const store = useAppStore();
  const cfg   = store.settings;
  const set   = (p: any) => store.updateSettings(p);

  const senLabels = ['', 'Minimal', 'Low', 'Moderate', 'Standard', 'Strict', 'High', 'Maximum'];
  const senColor  = cfg.sensitivity >= 6 ? Colors.danger : cfg.sensitivity >= 4 ? Colors.warn : Colors.safe;

  const clearFlags = () =>
    Alert.alert(
      'Clear All Flags',
      'Remove all flagged items from Norse AI\'s list? This does not delete any files.',
      [{ text: 'Cancel', style: 'cancel' }, { text: 'Clear', style: 'destructive', onPress: () => store.clearAllFlags() }]
    );

  return (
    <View style={s.root}>
      <View style={s.header}>
        <Text style={s.title}>Shield Settings</Text>
        <Text style={s.sub}>All processing on-device only · Zero data retention</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 36 }}>

        {/* ── Sensitivity ── */}
        <SH label="DETECTION SENSITIVITY" />
        <View style={s.section}>
          <View style={s.sensBlock}>
            <View style={s.sensHeader}>
              <View>
                <Text style={s.rowLbl}>Sensitivity Level</Text>
                <Text style={s.rowSub}>Content flagging threshold · 1–7</Text>
              </View>
              <Text style={[s.sensVal, { color: senColor }]}>{cfg.sensitivity}</Text>
            </View>
            <View style={s.stepRow}>
              <TouchableOpacity style={s.stepBtn} onPress={() => set({ sensitivity: Math.max(1, cfg.sensitivity - 1) })}>
                <Text style={{ color: Colors.text, fontSize: 20 }}>−</Text>
              </TouchableOpacity>
              <View style={s.track}>
                <View style={[s.trackFill, { width: `${((cfg.sensitivity - 1) / 6) * 100}%` as any, backgroundColor: senColor }]} />
                {[1,2,3,4,5,6,7].map(n => (
                  <TouchableOpacity key={n} onPress={() => set({ sensitivity: n })}
                    style={[s.notch, { left: `${((n-1)/6)*100}%` as any }]} />
                ))}
              </View>
              <TouchableOpacity style={s.stepBtn} onPress={() => set({ sensitivity: Math.min(7, cfg.sensitivity + 1) })}>
                <Text style={{ color: Colors.text, fontSize: 20 }}>+</Text>
              </TouchableOpacity>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 6 }}>
              <Text style={s.trackLbl}>Relaxed</Text>
              <Text style={[s.trackLbl, { color: senColor, fontWeight: '600' }]}>{senLabels[cfg.sensitivity]}</Text>
              <Text style={s.trackLbl}>Maximum</Text>
            </View>
          </View>

          <View style={s.divider} />

          <View style={s.windowBlock}>
            <View style={{ flex: 1 }}>
              <Text style={s.rowLbl}>Window Alert Limit</Text>
              <Text style={s.rowSub}>AI closes excess windows · 3–7</Text>
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <TouchableOpacity style={s.stepBtnSm} onPress={() => set({ windowLimit: Math.max(3, cfg.windowLimit - 1) })}>
                <Text style={{ color: Colors.text }}>−</Text>
              </TouchableOpacity>
              <Text style={[s.sensVal, { color: Colors.gold }]}>{cfg.windowLimit}</Text>
              <TouchableOpacity style={s.stepBtnSm} onPress={() => set({ windowLimit: Math.min(7, cfg.windowLimit + 1) })}>
                <Text style={{ color: Colors.text }}>+</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* ── Scan Categories ── */}
        <SH label="SCAN CATEGORIES" />
        <View style={s.section}>
          {[
            { k: 'scanNSFW',       icon: '🔞', l: 'Adult Content',    sub: 'NSFW image detection' },
            { k: 'scanViolence',   icon: '⚠️', l: 'Graphic Violence', sub: 'Disturbing imagery flags' },
            { k: 'scanSubstances', icon: '💊', l: 'Substances',       sub: 'Controlled substance content · Shield+' },
            { k: 'scanDarkweb',    icon: '🌑', l: 'Dark Web Refs',    sub: 'Sensitive document markers · Shield+' },
            { k: 'scanDocuments',  icon: '📄', l: 'Documents & IDs',  sub: 'Credentials and personal docs' },
          ].map(({ k, icon, l, sub }, i, arr) => (
            <Row key={k} icon={icon} label={l} sub={sub} last={i === arr.length - 1}
              right={<Toggle value={(cfg as any)[k]} onValueChange={v => set({ [k]: v })} />} />
          ))}
        </View>

        {/* ── Automation ── */}
        <SH label="AUTOMATION" />
        <View style={s.section}>
          {[
            { k: 'autoScan',          icon: '🔄', l: 'Auto Scan',          sub: 'Scan new media on arrival' },
            { k: 'lockScreenAlert',   icon: '🔒', l: 'Lock Screen Alert',  sub: 'Confirm before sharing flagged items' },
            { k: 'aiTips',            icon: '⚡', l: 'AI Pro Tips',        sub: 'Smart privacy recommendations' },
            { k: 'autoVault',         icon: '🗄', l: 'Auto Vault',         sub: 'Secure flagged items automatically · Shield+' },
            { k: 'biometricLock',     icon: '👁', l: 'Biometric Lock',     sub: 'Face ID / fingerprint for vault' },
            { k: 'notificationsEnabled', icon: '🔔', l: 'Notifications',   sub: 'Alerts and scan results' },
          ].map(({ k, icon, l, sub }, i, arr) => (
            <Row key={k} icon={icon} label={l} sub={sub} last={i === arr.length - 1}
              right={<Toggle value={(cfg as any)[k]} onValueChange={v => set({ [k]: v })} />} />
          ))}
        </View>

        {/* ── Data & Privacy ── */}
        <SH label="DATA & PRIVACY" />
        <View style={s.section}>
          <Row icon="🗺" label="Data Migration" sub="Viking tier · Coming soon"
            right={<Text style={s.soonBadge}>SOON</Text>} />
          <Row icon="📡" label="Data Tracking"  sub="Viking tier · Coming soon"
            right={<Text style={s.soonBadge}>SOON</Text>} />
          <Row icon="📋" label="Export Report"  sub="Generate privacy summary"
            right={<Text style={{ color: Colors.textMuted, fontSize: 16 }}>›</Text>} />
          <Row icon="🧹" label="Clear All Flags" sub="Reset flagged items list"
            onPress={clearFlags} last
            right={<Text style={{ color: Colors.danger, fontSize: 16 }}>›</Text>} />
        </View>

        <View style={s.about}>
          <Text style={s.aboutTxt}>Norse AI · v1.0.0-beta</Text>
          <Text style={s.aboutTxt}>Zero data retention · No external servers · 100% on-device</Text>
        </View>
      </ScrollView>
    </View>
  );
};

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.bg },
  header: { padding: Spacing.lg, paddingBottom: 4 },
  title: { fontSize: 22, color: Colors.text, letterSpacing: 1 },
  sub: { fontSize: 11, color: Colors.textMuted, marginTop: 2 },
  section: { marginHorizontal: Spacing.lg, backgroundColor: Colors.card, borderRadius: Radius.lg, borderWidth: 0.5, borderColor: Colors.border, overflow: 'hidden' },
  divider: { height: 0.5, backgroundColor: Colors.border },
  rowLbl: { fontSize: 14, color: Colors.text, fontWeight: '500' },
  rowSub: { fontSize: 11, color: Colors.textMuted, marginTop: 1 },
  sensBlock: { padding: Spacing.lg },
  sensHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 },
  sensVal: { fontSize: 28, fontWeight: '700' },
  stepRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  stepBtn: { width: 34, height: 34, borderRadius: Radius.sm, backgroundColor: Colors.border, alignItems: 'center', justifyContent: 'center' },
  track: { flex: 1, height: 4, backgroundColor: Colors.border, borderRadius: 2, position: 'relative' },
  trackFill: { position: 'absolute', left: 0, top: 0, height: '100%', borderRadius: 2 },
  notch: { position: 'absolute', top: -7, width: 4, height: 18, borderRadius: 2, backgroundColor: Colors.border, transform: [{ translateX: -2 }] },
  trackLbl: { fontSize: 10, color: Colors.textMuted },
  windowBlock: { flexDirection: 'row', alignItems: 'center', padding: Spacing.lg },
  stepBtnSm: { width: 28, height: 28, borderRadius: Radius.sm, backgroundColor: Colors.border, alignItems: 'center', justifyContent: 'center' },
  soonBadge: { fontSize: 10, color: Colors.gold, borderWidth: 1, borderColor: Colors.gold + '60', borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 },
  about: { padding: Spacing.xl, paddingTop: 12, alignItems: 'center', gap: 4 },
  aboutTxt: { fontSize: 11, color: Colors.textMuted },
});
