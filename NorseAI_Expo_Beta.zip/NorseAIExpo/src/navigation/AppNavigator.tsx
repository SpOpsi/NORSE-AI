// src/navigation/AppNavigator.tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { HomeScreen }         from '../screens/HomeScreen';
import { ScanScreen }         from '../screens/ScanScreen';
import { VaultScreen }        from '../screens/VaultScreen';
import { SettingsScreen }     from '../screens/SettingsScreen';
import { PlansScreen }        from '../screens/PlansScreen';
import { LockAlertScreen, OnboardingScreen } from '../screens/AlertAndOnboarding';
import { useAppStore } from '../context/AppStore';
import { Colors } from '../theme/colors';

const Tab   = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const THEME = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background:   Colors.bg,
    card:         Colors.surface,
    border:       Colors.border,
    text:         Colors.text,
    primary:      Colors.ice,
    notification: Colors.danger,
  },
};

const ICONS: Record<string, string> = { Home: '⬡', Scan: '◉', Vault: '◈', Settings: '◧', Plans: '◇' };

const TabIcon = ({ name, focused }: { name: string; focused: boolean }) => {
  const active = name === 'Plans' ? Colors.gold : Colors.ice;
  const color  = focused ? active : Colors.textMuted;
  return (
    <View style={ti.wrap}>
      <Text style={[ti.icon, { color }]}>{ICONS[name]}</Text>
      <Text style={[ti.lbl, { color, fontWeight: focused ? '600' : '400' }]}>{name}</Text>
    </View>
  );
};

const ti = StyleSheet.create({
  wrap: { alignItems: 'center', gap: 2 },
  icon: { fontSize: 19, lineHeight: 22 },
  lbl:  { fontSize: 9, letterSpacing: 0.5 },
});

const MainTabs = () => (
  <Tab.Navigator
    screenOptions={({ route }) => ({
      headerShown: false,
      tabBarShowLabel: false,
      tabBarStyle: {
        backgroundColor: Colors.surface,
        borderTopWidth: 0.5,
        borderTopColor: Colors.border,
        height: 72,
        paddingBottom: 16,
        paddingTop: 6,
      },
      tabBarIcon: ({ focused }) => <TabIcon name={route.name} focused={focused} />,
    })}
  >
    <Tab.Screen name="Home"     component={HomeScreen}     />
    <Tab.Screen name="Scan"     component={ScanScreen}     />
    <Tab.Screen name="Vault"    component={VaultScreen}    />
    <Tab.Screen name="Settings" component={SettingsScreen} />
    <Tab.Screen name="Plans"    component={PlansScreen}    />
  </Tab.Navigator>
);

export const AppNavigator: React.FC = () => {
  const store = useAppStore();

  return (
    <NavigationContainer theme={THEME}>
      <Stack.Navigator screenOptions={{ headerShown: false, animation: 'fade' }}>
        {!store.onboarded
          ? <Stack.Screen name="Onboarding" component={OnboardingScreen} />
          : <Stack.Screen name="Main"       component={MainTabs} />
        }
        <Stack.Screen
          name="LockAlert"
          component={LockAlertScreen}
          options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};
