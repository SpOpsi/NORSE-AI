// src/context/AppStore.ts
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type FlagSeverity = 'critical' | 'high' | 'medium' | 'low';
export type FlagType = 'nsfw' | 'graphic' | 'document' | 'screenshot' | 'substance' | 'darkweb';
export type Tier = 'scout' | 'shield' | 'viking';

export interface FlaggedItem {
  id: string;
  uri: string;
  type: FlagType;
  severity: FlagSeverity;
  category: string;
  confidence: number;
  detectedAt: string;
  secured: boolean;
  deleted: boolean;
  inVault: boolean;
  filePath: string;
  filename?: string;
  fileSize?: number;
}

export interface ScanStats {
  totalPhotos: number;
  totalVideos: number;
  totalScreenshots: number;
  totalDocuments: number;
  lastScanDate: string | null;
  totalFlagged: number;
  totalSecured: number;
  storageAnalyzed: number;
}

export interface Settings {
  sensitivity: number;
  windowLimit: number;
  autoScan: boolean;
  lockScreenAlert: boolean;
  aiTips: boolean;
  autoVault: boolean;
  scanNSFW: boolean;
  scanViolence: boolean;
  scanSubstances: boolean;
  scanDarkweb: boolean;
  scanDocuments: boolean;
  biometricLock: boolean;
  notificationsEnabled: boolean;
}

interface AppState {
  onboarded: boolean;
  tier: Tier;
  flags: FlaggedItem[];
  vaultItems: string[];
  stats: ScanStats;
  isScanning: boolean;
  scanProgress: number;
  scanStage: string;
  settings: Settings;
  pendingAlert: FlaggedItem | null;

  setOnboarded: (v: boolean) => void;
  setTier: (t: Tier) => void;
  addFlag: (f: FlaggedItem) => void;
  removeFlag: (id: string) => void;
  secureFlag: (id: string) => void;
  deleteFlag: (id: string) => void;
  moveToVault: (id: string) => void;
  deleteBulk: (ids: string[]) => void;
  clearAllFlags: () => void;
  setScanning: (v: boolean) => void;
  setScanProgress: (n: number) => void;
  setScanStage: (s: string) => void;
  updateStats: (s: Partial<ScanStats>) => void;
  updateSettings: (s: Partial<Settings>) => void;
  setPendingAlert: (item: FlaggedItem | null) => void;
  addVaultItem: (uri: string) => void;
}

const defaultSettings: Settings = {
  sensitivity: 5,
  windowLimit: 5,
  autoScan: true,
  lockScreenAlert: true,
  aiTips: true,
  autoVault: true,
  scanNSFW: true,
  scanViolence: true,
  scanSubstances: false,
  scanDarkweb: false,
  scanDocuments: true,
  biometricLock: true,
  notificationsEnabled: true,
};

const defaultStats: ScanStats = {
  totalPhotos: 0,
  totalVideos: 0,
  totalScreenshots: 0,
  totalDocuments: 0,
  lastScanDate: null,
  totalFlagged: 0,
  totalSecured: 0,
  storageAnalyzed: 0,
};

export const useAppStore = create<AppState>()(
  persist(
    immer((set) => ({
      onboarded: false,
      tier: 'scout' as Tier,
      flags: [],
      vaultItems: [],
      stats: defaultStats,
      isScanning: false,
      scanProgress: 0,
      scanStage: '',
      settings: defaultSettings,
      pendingAlert: null,

      setOnboarded: (v) => set(s => { s.onboarded = v; }),
      setTier: (t) => set(s => { s.tier = t; }),

      addFlag: (f) => set(s => {
        if (!s.flags.find(x => x.id === f.id)) {
          s.flags.unshift(f);
          s.stats.totalFlagged += 1;
        }
      }),

      removeFlag: (id) => set(s => { s.flags = s.flags.filter(f => f.id !== id); }),

      secureFlag: (id) => set(s => {
        const f = s.flags.find(x => x.id === id);
        if (f && !f.secured) { f.secured = true; s.stats.totalSecured += 1; }
      }),

      deleteFlag: (id) => set(s => { s.flags = s.flags.filter(f => f.id !== id); }),

      moveToVault: (id) => set(s => {
        const f = s.flags.find(x => x.id === id);
        if (f) {
          f.inVault = true;
          f.secured = true;
          if (!s.vaultItems.includes(f.uri)) s.vaultItems.push(f.uri);
        }
      }),

      deleteBulk: (ids) => set(s => { s.flags = s.flags.filter(f => !ids.includes(f.id)); }),
      clearAllFlags: () => set(s => { s.flags = []; s.stats.totalFlagged = 0; s.stats.totalSecured = 0; }),

      setScanning: (v) => set(s => { s.isScanning = v; }),
      setScanProgress: (n) => set(s => { s.scanProgress = n; }),
      setScanStage: (str) => set(s => { s.scanStage = str; }),

      updateStats: (partial) => set(s => { Object.assign(s.stats, partial); }),
      updateSettings: (partial) => set(s => { Object.assign(s.settings, partial); }),
      setPendingAlert: (item) => set(s => { s.pendingAlert = item; }),
      addVaultItem: (uri) => set(s => { if (!s.vaultItems.includes(uri)) s.vaultItems.push(uri); }),
    })),
    {
      name: 'norse-ai-store',
      storage: createJSONStorage(() => AsyncStorage),
      // Don't persist ephemeral scan state
      partialize: (state) => ({
        onboarded: state.onboarded,
        tier: state.tier,
        flags: state.flags,
        vaultItems: state.vaultItems,
        stats: state.stats,
        settings: state.settings,
      }),
    }
  )
);
