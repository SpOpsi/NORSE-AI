// src/services/VaultService.ts
/**
 * Norse Vault — encrypted on-device vault.
 * Uses expo-secure-store for metadata (AES-256, hardware-backed on both platforms)
 * and expo-file-system for file copies inside app sandbox.
 * Zero external transmission.
 */

import * as SecureStore from 'expo-secure-store';
import * as FileSystem from 'expo-file-system';
import * as LocalAuthentication from 'expo-local-authentication';

const VAULT_DIR  = `${FileSystem.documentDirectory}NorseVault/`;
const VAULT_KEY  = 'norse_vault_index_v1';
const MAX_SECURE = 2048; // SecureStore max value size per key
const CHUNK_KEY  = (i: number) => `norse_vault_chunk_${i}`;

export interface VaultEntry {
  id: string;
  originalUri: string;
  vaultPath: string;
  filename: string;
  mediaType: 'photo' | 'video' | 'document';
  size: number;
  addedAt: string;
}

class NorseVaultService {
  private ready = false;

  async init() {
    if (this.ready) return;
    const info = await FileSystem.getInfoAsync(VAULT_DIR);
    if (!info.exists) await FileSystem.makeDirectoryAsync(VAULT_DIR, { intermediates: true });
    this.ready = true;
  }

  async authenticate(): Promise<boolean> {
    const compatible = await LocalAuthentication.hasHardwareAsync();
    const enrolled   = await LocalAuthentication.isEnrolledAsync();
    if (!compatible || !enrolled) return true; // fallback: allow without biometric

    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: 'Unlock Norse Vault',
      cancelLabel: 'Cancel',
      disableDeviceFallback: false,
    });
    return result.success;
  }

  async addToVault(uri: string): Promise<VaultEntry | null> {
    await this.init();
    try {
      const id   = `v_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const ext  = uri.split('.').pop()?.split('?')[0] ?? 'jpg';
      const dest = `${VAULT_DIR}${id}.${ext}`;
      await FileSystem.copyAsync({ from: uri, to: dest });
      const info = await FileSystem.getInfoAsync(dest, { size: true });
      const entry: VaultEntry = {
        id,
        originalUri: uri,
        vaultPath: dest,
        filename: `${id}.${ext}`,
        mediaType: ['mp4','mov','avi','mkv'].includes(ext) ? 'video' : 'photo',
        size: (info as any).size ?? 0,
        addedAt: new Date().toISOString(),
      };
      await this.saveEntry(entry);
      return entry;
    } catch (e) {
      console.error('[Vault] addToVault error:', e);
      return null;
    }
  }

  async getEntries(): Promise<VaultEntry[]> {
    try {
      // Read chunked storage
      let all = '';
      let i = 0;
      while (true) {
        const chunk = await SecureStore.getItemAsync(CHUNK_KEY(i));
        if (!chunk) break;
        all += chunk;
        i++;
      }
      return all ? JSON.parse(all) : [];
    } catch {
      return [];
    }
  }

  async removeEntry(id: string): Promise<void> {
    const entries = await this.getEntries();
    const entry   = entries.find(e => e.id === id);
    if (entry) {
      try { await FileSystem.deleteAsync(entry.vaultPath, { idempotent: true }); } catch {}
    }
    await this.writeEntries(entries.filter(e => e.id !== id));
  }

  async clearVault(): Promise<void> {
    const entries = await this.getEntries();
    for (const e of entries) {
      try { await FileSystem.deleteAsync(e.vaultPath, { idempotent: true }); } catch {}
    }
    await this.writeEntries([]);
  }

  async getVaultSize(): Promise<number> {
    const entries = await this.getEntries();
    return entries.reduce((s, e) => s + e.size, 0);
  }

  private async saveEntry(entry: VaultEntry) {
    const entries = await this.getEntries();
    entries.unshift(entry);
    await this.writeEntries(entries);
  }

  // SecureStore has a 2KB limit per key — chunk the JSON
  private async writeEntries(entries: VaultEntry[]) {
    const json   = JSON.stringify(entries);
    const chunks = [];
    for (let i = 0; i < json.length; i += MAX_SECURE) {
      chunks.push(json.slice(i, i + MAX_SECURE));
    }
    // Clear old chunks
    let i = 0;
    while (true) {
      const existing = await SecureStore.getItemAsync(CHUNK_KEY(i));
      if (!existing) break;
      await SecureStore.deleteItemAsync(CHUNK_KEY(i));
      i++;
    }
    // Write new chunks
    for (let j = 0; j < chunks.length; j++) {
      await SecureStore.setItemAsync(CHUNK_KEY(j), chunks[j]);
    }
  }
}

export const Vault = new NorseVaultService();
