// src/services/ScannerService.ts
/**
 * Norse AI Scanner — 100% on-device, zero external transmission.
 * Uses expo-media-library to access photos and a heuristic
 * keyword/metadata classifier (ML Kit is not available in Expo Go;
 * for production EAS builds add @react-native-ml-kit/image-labeling
 * as a dev client plugin and swap classifyAsset below).
 */

import * as MediaLibrary from 'expo-media-library';
import * as FileSystem from 'expo-file-system';
import { FlaggedItem, FlagSeverity, FlagType } from '../context/AppStore';
import { genId } from '../utils/uuid';

// ── Confidence thresholds per sensitivity level 1–7 ──────────────────────────
const THRESHOLD: Record<number, number> = {
  1: 0.95, 2: 0.90, 3: 0.82, 4: 0.74, 5: 0.65, 6: 0.55, 7: 0.40,
};

// ── Filename / album heuristics (used until ML Kit is wired in EAS build) ────
const NSFW_HINTS      = ['nude','naked','nsfw','xxx','porn','sex','adult','explicit','onlyfans','lingerie'];
const GRAPHIC_HINTS   = ['gore','blood','violence','accident','crash','wound','weapon','fight'];
const SUBSTANCE_HINTS = ['weed','drugs','cocaine','pills','420','substance'];
const DARKWEB_HINTS   = ['passport','ssn','bankcard','cvv','wallet_seed','private_key','license'];
const SCREENSHOT_HINTS= ['screenshot','screen_record','screenrecord','screencap'];
const DOC_HINTS       = ['invoice','receipt','contract','statement','tax','w2','1099','deed'];

export interface ScanProgress {
  current: number;
  total: number;
  stage: string;
  percentComplete: number;
}

export interface ScanResult {
  flaggedItems: FlaggedItem[];
  stats: {
    totalScanned: number;
    totalPhotos: number;
    totalVideos: number;
    totalScreenshots: number;
    bytesAnalyzed: number;
    durationMs: number;
  };
}

type ProgressCB = (p: ScanProgress) => void;

class NorseScannerService {
  private aborted = false;

  abort() { this.aborted = true; }

  async requestPermissions(): Promise<boolean> {
    const { status } = await MediaLibrary.requestPermissionsAsync();
    return status === 'granted';
  }

  async scanDevice(
    sensitivity: number,
    scanTypes: { nsfw: boolean; violence: boolean; substances: boolean; darkweb: boolean; documents: boolean },
    onProgress: ProgressCB
  ): Promise<ScanResult> {
    this.aborted = false;
    const t0 = Date.now();
    const flags: FlaggedItem[] = [];
    const threshold = THRESHOLD[sensitivity] ?? 0.65;

    onProgress({ current: 0, total: 0, stage: 'Loading media library…', percentComplete: 1 });

    // ── Fetch all assets ──────────────────────────────────────────────────────
    let allAssets: MediaLibrary.Asset[] = [];
    let cursor: string | undefined;
    let hasMore = true;

    while (hasMore && !this.aborted) {
      const page = await MediaLibrary.getAssetsAsync({
        first: 300,
        after: cursor,
        mediaType: [MediaLibrary.MediaType.photo, MediaLibrary.MediaType.video],
        sortBy: MediaLibrary.SortBy.creationTime,
      });
      allAssets = allAssets.concat(page.assets);
      hasMore = page.hasNextPage;
      cursor = page.endCursor;
    }

    const total = allAssets.length;
    let totalPhotos = 0, totalVideos = 0, totalScreenshots = 0, bytesAnalyzed = 0;

    onProgress({ current: 0, total, stage: `Analyzing ${total} items…`, percentComplete: 3 });

    for (let i = 0; i < allAssets.length; i++) {
      if (this.aborted) break;

      const asset = allAssets[i];
      const name = (asset.filename ?? '').toLowerCase();
      const album = (asset.albumId ?? '').toLowerCase();

      if (asset.mediaType === 'video') totalVideos++;
      else if (SCREENSHOT_HINTS.some(h => name.includes(h) || album.includes(h))) totalScreenshots++;
      else totalPhotos++;

      bytesAnalyzed += asset.duration > 0 ? asset.duration * 2_000_000 : 500_000;

      if (i % 15 === 0) {
        const pct = Math.min(97, Math.round((i / total) * 94) + 3);
        onProgress({ current: i, total, stage: `Scanning ${i + 1} of ${total}…`, percentComplete: pct });
      }

      const hit = this.classify(name, album, threshold, scanTypes);
      if (hit) {
        flags.push({
          id: genId(),
          uri: asset.uri,
          type: hit.type,
          severity: hit.severity,
          category: hit.category,
          confidence: hit.confidence,
          detectedAt: new Date().toISOString(),
          secured: false,
          deleted: false,
          inVault: false,
          filePath: asset.uri,
          filename: asset.filename,
          fileSize: asset.duration > 0 ? asset.duration * 2_000_000 : 500_000,
        });
      }
    }

    onProgress({ current: total, total, stage: 'Scan complete.', percentComplete: 100 });

    return {
      flaggedItems: flags,
      stats: { totalScanned: total, totalPhotos, totalVideos, totalScreenshots, bytesAnalyzed, durationMs: Date.now() - t0 },
    };
  }

  private classify(
    name: string,
    album: string,
    threshold: number,
    types: Record<string, boolean>
  ): { type: FlagType; severity: FlagSeverity; category: string; confidence: number } | null {
    const check = (hints: string[], boost = 0) => {
      const matches = hints.filter(h => name.includes(h) || album.includes(h));
      if (matches.length === 0) return 0;
      return Math.min(0.99, 0.60 + matches.length * 0.12 + boost);
    };

    const scores: Array<{ type: FlagType; cat: string; score: number }> = [];

    if (types.nsfw) {
      const s = check(NSFW_HINTS, 0.10);
      if (s > 0) scores.push({ type: 'nsfw', cat: 'Adult Content', score: s });
    }
    if (types.violence) {
      const s = check(GRAPHIC_HINTS, 0.05);
      if (s > 0) scores.push({ type: 'graphic', cat: 'Graphic Violence', score: s });
    }
    if (types.substances) {
      const s = check(SUBSTANCE_HINTS);
      if (s > 0) scores.push({ type: 'substance', cat: 'Substance Content', score: s });
    }
    if (types.darkweb) {
      const s = check(DARKWEB_HINTS, 0.08);
      if (s > 0) scores.push({ type: 'darkweb', cat: 'Sensitive Document', score: s });
    }
    if (types.documents) {
      const s = check(DOC_HINTS);
      if (s > 0) scores.push({ type: 'document', cat: 'Document Detected', score: s });
    }
    // Screenshots with sensitive context
    const ssScore = check(SCREENSHOT_HINTS, -0.10);
    if (ssScore > threshold) scores.push({ type: 'screenshot', cat: 'Screenshot', score: ssScore });

    const best = scores.sort((a, b) => b.score - a.score)[0];
    if (!best || best.score < threshold) return null;

    const sev: FlagSeverity = best.score >= 0.88 ? 'critical' : best.score >= 0.75 ? 'high' : best.score >= 0.62 ? 'medium' : 'low';
    return { type: best.type, severity: sev, category: best.cat, confidence: best.score };
  }
}

export const Scanner = new NorseScannerService();
