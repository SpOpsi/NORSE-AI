// src/services/NotificationService.ts
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { FlaggedItem } from '../context/AppStore';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

class NorseNotificationService {
  async setup() {
    const { status: existing } = await Notifications.getPermissionsAsync();
    let finalStatus = existing;
    if (existing !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('norse-alerts', {
        name: 'Norse Guard Alerts',
        importance: Notifications.AndroidImportance.HIGH,
        vibrationPattern: [0, 250, 100, 250],
        lightColor: '#E05252',
        sound: 'default',
      });
      await Notifications.setNotificationChannelAsync('norse-scan', {
        name: 'Scan Results',
        importance: Notifications.AndroidImportance.DEFAULT,
      });
      await Notifications.setNotificationChannelAsync('norse-tips', {
        name: 'Norse AI Tips',
        importance: Notifications.AndroidImportance.LOW,
      });
    }
    return finalStatus === 'granted';
  }

  async flagAlert(item: FlaggedItem) {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: '⚠ Norse Guard Alert',
        body: `${item.category} detected — tap to review before sharing`,
        data: { flagId: item.id },
        color: '#E05252',
        sound: 'default',
        priority: Notifications.AndroidNotificationPriority.HIGH,
      },
      trigger: null,
    });
  }

  async scanComplete(flagCount: number, totalScanned: number) {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: flagCount > 0
          ? `⚠ ${flagCount} Item${flagCount > 1 ? 's' : ''} Flagged`
          : '✦ Device Protected',
        body: flagCount > 0
          ? `Norse AI found ${flagCount} sensitive item${flagCount > 1 ? 's' : ''} from ${totalScanned} scanned.`
          : `${totalScanned} items scanned. No sensitive content detected.`,
        color: flagCount > 0 ? '#D4882A' : '#45C49A',
      },
      trigger: null,
    });
  }

  async proTip(tip: string) {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: '⚡ Norse AI Tip',
        body: tip,
        color: '#C9A84C',
      },
      trigger: null,
    });
  }
}

export const NorseNotifications = new NorseNotificationService();
