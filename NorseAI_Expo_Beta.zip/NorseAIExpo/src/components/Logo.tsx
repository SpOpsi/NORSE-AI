// src/components/Logo.tsx
import React from 'react';
import { Image, ImageStyle, StyleProp } from 'react-native';

const ICON  = require('../assets/images/norse_icon.png');
const BRAND = require('../assets/images/norse_brand.png');

interface LogoProps {
  size?: number;
  style?: StyleProp<ImageStyle>;
}
interface BrandProps {
  width?: number;
  style?: StyleProp<ImageStyle>;
}

/** Square icon — nav headers, stat cards, lock alert */
export const NorseLogo: React.FC<LogoProps> = ({ size = 48, style }) => (
  <Image
    source={ICON}
    style={[{ width: size, height: size, borderRadius: size * 0.22 }, style as any]}
    resizeMode="contain"
  />
);

/** Wide lockup with "NORSE AI" wordmark — onboarding splash, plans header */
export const NorseBrand: React.FC<BrandProps> = ({ width = 260, style }) => (
  <Image
    source={BRAND}
    style={[{ width, height: width * 0.46 }, style as any]}
    resizeMode="contain"
  />
);

/** Raw icon, no border radius — for use inside shaped containers */
export const NorseIconRaw: React.FC<LogoProps> = ({ size = 48, style }) => (
  <Image
    source={ICON}
    style={[{ width: size, height: size }, style as any]}
    resizeMode="contain"
  />
);
