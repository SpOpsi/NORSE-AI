// src/components/UI.tsx
import React from 'react';
import {
  View, Text, Switch, TouchableOpacity,
  StyleSheet, ActivityIndicator,
  ViewStyle, TextStyle,
} from 'react-native';
import { Colors, Radius, Spacing } from '../theme/colors';

// ── Toggle ────────────────────────────────────────────────────────────────────
export const Toggle: React.FC<{ value: boolean; onValueChange: (v: boolean) => void }> = ({ value, onValueChange }) => (
  <Switch
    value={value}
    onValueChange={onValueChange}
    trackColor={{ false: Colors.border, true: Colors.ice + '60' }}
    thumbColor={value ? Colors.ice : Colors.textMuted}
    ios_backgroundColor={Colors.border}
  />
);

// ── Button ────────────────────────────────────────────────────────────────────
interface BtnProps {
  label: string;
  onPress: () => void;
  color?: string;
  loading?: boolean;
  disabled?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
}
export const Button: React.FC<BtnProps> = ({ label, onPress, color = Colors.ice, loading, disabled, style, textStyle }) => (
  <TouchableOpacity
    onPress={onPress}
    activeOpacity={0.75}
    disabled={disabled || loading}
    style={[styles.btn, { borderColor: color, backgroundColor: color + '14' }, disabled ? { opacity: 0.4 } : {}, style]}
  >
    {loading
      ? <ActivityIndicator color={color} size="small" />
      : <Text style={[styles.btnTxt, { color }, textStyle]}>{label}</Text>}
  </TouchableOpacity>
);

// ── Card ──────────────────────────────────────────────────────────────────────
interface CardProps { children: React.ReactNode; style?: ViewStyle; onPress?: () => void; accent?: string }
export const Card: React.FC<CardProps> = ({ children, style, onPress, accent }) => {
  const inner = <View style={[styles.card, accent ? { borderColor: accent + '50' } : {}, style]}>{children}</View>;
  return onPress ? <TouchableOpacity onPress={onPress} activeOpacity={0.75}>{inner}</TouchableOpacity> : inner;
};

// ── Row ───────────────────────────────────────────────────────────────────────
interface RowProps { icon: string; label: string; sub?: string; right?: React.ReactNode; onPress?: () => void; last?: boolean }
export const Row: React.FC<RowProps> = ({ icon, label, sub, right, onPress, last }) => {
  const inner = (
    <View style={[styles.row, !last && styles.rowBorder]}>
      <View style={styles.rowIcon}><Text style={{ fontSize: 15 }}>{icon}</Text></View>
      <View style={{ flex: 1 }}>
        <Text style={styles.rowLbl}>{label}</Text>
        {sub ? <Text style={styles.rowSub}>{sub}</Text> : null}
      </View>
      {right && <View style={{ flexShrink: 0 }}>{right}</View>}
    </View>
  );
  return onPress ? <TouchableOpacity onPress={onPress} activeOpacity={0.7}>{inner}</TouchableOpacity> : inner;
};

// ── Badge ─────────────────────────────────────────────────────────────────────
export const Badge: React.FC<{ label: string; color: string }> = ({ label, color }) => (
  <View style={[styles.badge, { borderColor: color + '60', backgroundColor: color + '20' }]}>
    <Text style={[styles.badgeTxt, { color }]}>{label}</Text>
  </View>
);

// ── Section Header ────────────────────────────────────────────────────────────
export const SH: React.FC<{ label: string }> = ({ label }) => (
  <Text style={styles.sh}>{label}</Text>
);

const styles = StyleSheet.create({
  btn: {
    borderWidth: 1, borderRadius: Radius.md,
    paddingVertical: 14, paddingHorizontal: Spacing.lg,
    alignItems: 'center', justifyContent: 'center',
  },
  btnTxt: { fontSize: 13, fontWeight: '700', letterSpacing: 1.5 },
  card: {
    backgroundColor: Colors.card, borderRadius: Radius.lg,
    borderWidth: 0.5, borderColor: Colors.border, padding: Spacing.lg,
  },
  row: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    paddingVertical: 12, paddingHorizontal: Spacing.lg,
  },
  rowBorder: { borderBottomWidth: 0.5, borderBottomColor: Colors.border },
  rowIcon: {
    width: 34, height: 34, borderRadius: Radius.sm,
    backgroundColor: Colors.elevated, alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
  rowLbl: { fontSize: 14, color: Colors.text, fontWeight: '500' },
  rowSub: { fontSize: 11, color: Colors.textMuted, marginTop: 1 },
  badge: {
    borderWidth: 1, borderRadius: Radius.xs,
    paddingHorizontal: 6, paddingVertical: 2,
  },
  badgeTxt: { fontSize: 10, fontWeight: '700', letterSpacing: 0.5 },
  sh: {
    fontSize: 10, color: Colors.textMuted, letterSpacing: 2,
    fontWeight: '600', paddingHorizontal: Spacing.lg,
    paddingTop: 16, paddingBottom: 6, textTransform: 'uppercase',
  },
});
