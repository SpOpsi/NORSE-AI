// App.tsx — Norse AI Expo Entry
import React, { useEffect, useCallback } from 'react';
import { StatusBar, View } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import * as SplashScreen from 'expo-splash-screen';
import * as Font from 'expo-font';
import { useAppStore } from './src/context/AppStore';
import { AppNavigator } from './src/navigation/AppNavigator';
import { Vault } from './src/services/VaultService';
import { NorseNotifications } from './src/services/NotificationService';
import { Scanner } from './src/services/ScannerService';
import { Colors } from './src/theme/colors';

SplashScreen.preventAutoHideAsync();

export default function App() {
  const store   = useAppStore();
  const [ready, setReady] = React.useState(false);

  useEffect(() => {
    async function init() {
      try {
        // Init vault directory
        await Vault.init();

        // Setup notifications
        if (store.settings.notificationsEnabled) {
          await NorseNotifications.setup();
        }

        // Auto-scan if enabled and last scan was > 12h ago
        if (store.settings.autoScan && store.onboarded) {
          const lastScan   = store.stats.lastScanDate;
          const hoursSince = lastScan
            ? (Date.now() - new Date(lastScan).getTime()) / 3_600_000
            : Infinity;

          if (hoursSince > 12) {
            const ok = await Scanner.requestPermissions();
            if (ok) {
              store.setScanning(true);
              Scanner.scanDevice(
                store.settings.sensitivity,
                {
                  nsfw:       store.settings.scanNSFW,
                  violence:   store.settings.scanViolence,
                  substances: store.settings.scanSubstances,
                  darkweb:    store.settings.scanDarkweb,
                  documents:  store.settings.scanDocuments,
                },
                (p) => { store.setScanProgress(p.percentComplete); store.setScanStage(p.stage); }
              ).then(async (result) => {
                for (const item of result.flaggedItems) store.addFlag(item);
                store.updateStats({
                  totalPhotos:    result.stats.totalPhotos,
                  totalVideos:    result.stats.totalVideos,
                  lastScanDate:   new Date().toISOString(),
                  storageAnalyzed: result.stats.bytesAnalyzed,
                });
                await NorseNotifications.scanComplete(result.flaggedItems.length, result.stats.totalScanned);
              }).finally(() => store.setScanning(false));
            }
          }
        }
      } catch (e) {
        console.error('[Init]', e);
      } finally {
        setReady(true);
      }
    }
    init();
  }, []);

  const onLayoutRootView = useCallback(async () => {
    if (ready) await SplashScreen.hideAsync();
  }, [ready]);

  if (!ready) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: Colors.bg }} onLayout={onLayoutRootView}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.bg} />
      <AppNavigator />
    </GestureHandlerRootView>
  );
}
