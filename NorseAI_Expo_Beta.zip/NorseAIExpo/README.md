# ⬡ Norse AI — Expo Beta Build Guide
### From zero to APK on your phone in under 2 hours

---

## What's inside

```
NorseAIExpo/
├── App.tsx                          Root — splash, init, auto-scan
├── app.json                         Expo config — permissions, icons, build
├── eas.json                         EAS Build profiles (dev / beta / production)
├── src/
│   ├── screens/
│   │   ├── HomeScreen.tsx           Dashboard, shield score, scan trigger
│   │   ├── ScanScreen.tsx           Flagged items, bulk delete, filter
│   │   ├── VaultScreen.tsx          Biometric vault (expo-secure-store)
│   │   ├── SettingsScreen.tsx       All toggles, sensitivity, window limit
│   │   ├── PlansScreen.tsx          Scout / Shield / Viking tiers
│   │   └── AlertAndOnboarding.tsx   Lock screen alert + 5-step onboarding
│   ├── services/
│   │   ├── ScannerService.ts        On-device scanner (expo-media-library)
│   │   ├── VaultService.ts          Encrypted vault (expo-secure-store + file-system)
│   │   └── NotificationService.ts  Local alerts (expo-notifications)
│   ├── context/AppStore.ts          Zustand + AsyncStorage state
│   ├── components/
│   │   ├── Logo.tsx                 Real PNG logo assets wired
│   │   └── UI.tsx                   Toggle, Button, Card, Row, Badge
│   ├── navigation/AppNavigator.tsx  Stack + bottom tabs
│   ├── theme/colors.ts              Design tokens
│   └── utils/uuid.ts               ID gen + format helpers
└── assets/
    ├── icon.png                     App store icon (your logo)
    ├── adaptive-icon.png            Android adaptive icon
    └── splash.png                   Splash screen (brand lockup)
```

---

## STEP 1 — One-time account setup (5 min)

### a) Create an Expo account (free)
👉 https://expo.dev/signup

### b) Install tools
```bash
npm install -g expo-cli eas-cli
eas login   # sign in with your Expo account
```

### c) Get your Project ID
```bash
cd NorseAIExpo
eas init    # creates projectId and links to your account
```
Copy the `projectId` it gives you and paste it into `app.json`:
```json
"extra": { "eas": { "projectId": "PASTE_HERE" } }
```
Also set `"owner": "YOUR_EXPO_USERNAME"` in `app.json`.

---

## STEP 2 — Install dependencies (3 min)

```bash
cd NorseAIExpo
npm install
```

That's it. No CocoaPods. No Android SDK setup. EAS handles all of that in the cloud.

---

## STEP 3 — Build your Android APK (beta) ☑ Recommended first

```bash
eas build --profile beta --platform android
```

EAS will:
1. Upload your code to Expo's build servers
2. Compile the native Android APK (takes ~10–15 min first time)
3. Give you a **download link** for the APK

**Install on your Android phone:**
- Download the APK link to your phone
- Open it to install (you may need to allow "Install from unknown sources" in Settings > Security)
- Norse AI launches immediately ✓

---

## STEP 4 — Build your iOS beta (requires Apple account)

### You need:
- Apple Developer account: https://developer.apple.com ($99/yr)
- Once enrolled, run:

```bash
eas build --profile beta --platform ios
```

EAS will ask for your Apple ID, handle signing automatically, and produce an `.ipa`.

**Distribute via TestFlight:**
```bash
eas submit --platform ios
```
Then go to https://appstoreconnect.apple.com → TestFlight → add your testers by email.

---

## STEP 5 — Share with beta testers

### Android testers (easiest — no account needed)
Send them the APK download link directly from EAS.  
They install it, done.

### iOS testers  
Add their Apple IDs in TestFlight. They get an email to install.

### Using Expo Go (for quick UI preview only)
```bash
npx expo start
```
Scan the QR with the Expo Go app on your phone.  
⚠️ Note: `expo-media-library` and `expo-local-authentication` run in full builds only,  
not in Expo Go. Use this for visual QA only.

---

## STEP 6 — Update the app without rebuilding

Once your app is installed, push code updates over the air:
```bash
eas update --branch beta --message "Fixed scan progress display"
```
Users get the update automatically next time they open the app. No new APK needed.

---

## Test Checklist (run on both platforms)

- [ ] Launch → 5-step onboarding displays brand logo on step 1
- [ ] Grant photo library permissions when prompted
- [ ] Tap "INITIATE DEEP SCAN" → progress bar runs → scan completes
- [ ] Flagged items appear on Scan tab with category + confidence
- [ ] Tap a flag → Lock Alert modal appears with haptic feedback
- [ ] "Move to Vault" → biometric prompt → item secured
- [ ] Vault screen shows items locked behind Face ID
- [ ] Settings: sensitivity slider 1–7 works
- [ ] Settings: window limit stepper 3–7 works
- [ ] All toggles save and persist after app restart
- [ ] Plans screen shows all 3 tiers + payment methods
- [ ] Shield score updates as items are secured
- [ ] App closes and reopens — all data persists

---

## app.json fields to update before first build

| Field | Where | What to put |
|-------|-------|-------------|
| `projectId` | `extra.eas.projectId` | From `eas init` |
| `owner` | root | Your Expo username |
| `bundleIdentifier` | `ios` | e.g. `com.norseai.app` |
| `package` | `android` | e.g. `com.norseai.app` |

---

## Production release (after beta)

### Android — Google Play Store
```bash
eas build --profile production --platform android   # builds .aab
eas submit --platform android                        # uploads to Play Console
```

### iOS — App Store
```bash
eas build --profile production --platform ios
eas submit --platform ios
```

**App Store listing tips:**
- Category: **Utilities**  
- Description: Lead with "100% on-device" — this differentiates you
- Privacy Nutrition Label: check "No data collected"
- Keywords: privacy, photo cleaner, vault, sensitive content, device cleaner

---

## Pricing / IAP wiring (before production)

The Plans screen currently sets tier locally. Before production, wire RevenueCat:

```bash
npm install react-native-purchases
```

```typescript
// In App.tsx
import Purchases from 'react-native-purchases';
Purchases.configure({ apiKey: 'YOUR_REVENUECAT_KEY' });
```

Create products in App Store Connect + Google Play:
- `com.norseai.shield.monthly`  →  $4.99
- `com.norseai.shield.annual`   →  $39.99
- `com.norseai.viking.monthly`  →  $12.99
- `com.norseai.viking.annual`   →  $99.99

Crypto payments → web portal at `norseai.app/pay` → user gets activation code → enters in app.

---

## Common errors and fixes

| Error | Fix |
|-------|-----|
| `eas: command not found` | Run `npm install -g eas-cli` |
| `projectId not found` | Run `eas init` in project root |
| Build fails on iOS signing | Follow EAS prompts — it walks you through credentials |
| `expo-media-library` not working in Expo Go | Normal — use full build |
| AsyncStorage warning | Already using correct package — ignore |

---

*"Huginn sees all. Muninn remembers nothing."*  
**Norse AI — Zero data. Full protection.**
